import entities.Carrera;
import entities.Facultad;
import jakarta.persistence.EntityManager;
import utils.JpaUtil;

import javax.swing.*;
import java.util.List;

public class HibernateCrear {
    public static void main(String[] args) {
        EntityManager em = JpaUtil.getEntityManager();

        try {
            em.getTransaction().begin();
            // Se usa JOptionPane para solicitar datos al usuario
            String nombre= JOptionPane.showInputDialog("Ingrese nombre de carrera");
            String tipo=JOptionPane.showInputDialog("Digite el tipo de carrera");
            int facultadId = Integer.parseInt(JOptionPane.showInputDialog("Digite el id de la facultad"));

            Facultad facultad = em.createQuery("SELECT f FROM Facultad f WHERE f.id = :facultadId", Facultad.class)
                    .setParameter("facultadId", facultadId)
                    .getSingleResult();
            Carrera ca = new Carrera();
            ca.setNombre(nombre);
            ca.setTipo(tipo);
            ca.setFacultad(facultad);

            em.persist(ca);
            em.getTransaction().commit();
            System.out.println("Carrera creada exitosamente: " + ca);

        } catch (Exception e) {
            //En caso de error se retorna la transacción o se cancela
            em.getTransaction().rollback();
            //Imprimir la traza
            e.printStackTrace();

        } finally {
            //Siempre cerrar la conexion de entitymanager
            em.close();

        }
    }
}
