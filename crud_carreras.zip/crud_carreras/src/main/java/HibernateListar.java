import entities.Carrera;
import entities.Facultad;
import jakarta.persistence.EntityManager;
import utils.JpaUtil;

import java.util.List;

public class HibernateListar {
    public static void main(String[] args) {
        EntityManager entityManager =JpaUtil.getEntityManager();

        List<Carrera> carreras = entityManager.createQuery("SELECT c FROM Carrera c", Carrera.class).getResultList();
        carreras.forEach(System.out::println);

    }
}
