import entities.Carrera;
import entities.Facultad;
import jakarta.persistence.EntityManager;
import utils.JpaUtil;

import javax.swing.*;

public class HibernateDelete {
    public static void main(String[] args) {
        EntityManager em = JpaUtil.getEntityManager();

        try {
            // Iniciar transacción
            em.getTransaction().begin();

            // Solicitar el ID de la carrera a eliminar
            int carreraId = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID de la carrera a eliminar"));

            // Buscar la carrera en la base de datos
            Carrera carrera = em.find(Carrera.class, carreraId);

            if (carrera != null) {
                // Eliminar la carrera
                em.remove(carrera);

                // Confirmar la transacción
                em.getTransaction().commit();
                System.out.println("Carrera eliminada exitosamente.");
            } else {
                System.out.println("Carrera no encontrada.");
                em.getTransaction().rollback();
            }

        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}
