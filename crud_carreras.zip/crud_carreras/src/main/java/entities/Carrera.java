package entities;

import jakarta.persistence.*;

@Entity
@Table(name = "carreras")
public class Carrera {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idcarrera")
    private int idCarrera;

    @Column(name = "nombre", length = 150, nullable = false)
    private String nombre;

    @Column(name = "tipo",length = 40, nullable = false)
    private String tipo;

    @ManyToOne
    @JoinColumn(name = "idfacultad", nullable = false)
    private Facultad facultad;

    public Facultad getFacultad() {
        return facultad;
    }

    public Carrera() {
    }

    public void setFacultad(Facultad facultad) {
        this.facultad = facultad;
    }

    public int getIdCarrera() {
        return idCarrera;
    }

    public void setIdCarrera(int idCarrera) {
        this.idCarrera = idCarrera;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Carrera{" +
                "idCarrera=" + idCarrera +
                ", nombre='" + nombre + '\'' +
                ", tipo=" + tipo +
                ", facultad=" + facultad.getAbreviatura() +
                '}';
    }
}