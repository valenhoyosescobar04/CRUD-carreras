import entities.Carrera;
import jakarta.persistence.EntityManager;
import utils.JpaUtil;

import javax.swing.*;

public class HibernateEditar {
    public static void main(String[] args) {
        EntityManager em = JpaUtil.getEntityManager();

        try {
            em.getTransaction().begin();

            // Solicitar ID de la carrera que se desea editar
            int carreraId = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID de la carrera a editar"));

            // Buscar la carrera en la base de datos
            Carrera carrera = em.find(Carrera.class, carreraId);

            if (carrera != null) {
                // Solicitar nuevos valores
                String nuevoNombre = JOptionPane.showInputDialog("Ingrese el nuevo nombre de la carrera", carrera.getNombre());
                String nuevoTipo = JOptionPane.showInputDialog("Digite el nuevo tipo de carrera", carrera.getTipo());

                carrera.setNombre(nuevoNombre);
                carrera.setTipo(nuevoTipo);

                // Actualizar la entidad
                em.merge(carrera);

                // Confirmar la transacción
                em.getTransaction().commit();
                System.out.println("Carrera editada exitosamente: " + carrera);
            } else {
                System.out.println("Carrera no encontrada.");
                em.getTransaction().rollback();
            }

        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}
